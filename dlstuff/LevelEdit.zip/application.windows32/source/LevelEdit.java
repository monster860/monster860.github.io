import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.video.*; 
import ddf.minim.spi.*; 
import ddf.minim.signals.*; 
import ddf.minim.*; 
import ddf.minim.analysis.*; 
import ddf.minim.ugens.*; 
import ddf.minim.effects.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class LevelEdit extends PApplet {










ArrayList bokses = new ArrayList();
ArrayList trians = new ArrayList();
int puller = 0;
int translator;
int linie = 600;
int x;
int y;
int fall = 0;
int setter = 0;

boolean isFirst = true;
public void setup() {
  size(displayWidth - 150, displayHeight - 80);
  XML xml = loadXML("daten.xml");  
  XML points = xml.getChild(1);
  XML trianer = xml.getChild(3);
  for (int i = 0; i < points.getChildCount(); i++) {
    XML punkt = points.getChild(i);
    if ((punkt + "").equals("")) continue;
    bokses.add(new Boks(punkt.getFloat("x") * 50 - puller, punkt.getFloat("y")));
  }
  for (int i = 0; i < trianer.getChildCount(); i++) {
    XML trian = trianer.getChild(i);
    if ((trian + "").equals("")) continue;
        System.out.println("\"" + trian + "\"");
    trians.add(new Trian(trian.getFloat("x") * 50 - puller, trian.getFloat("y")));
  }
}
boolean clearFlag;
public void draw() {
  textSize(32);
  rectMode(CENTER);
  background(200);

  if (keyPressed) {
    if (key == 'a') {
      translator += 10;
    }
    if (key == 'd') {
      translator -= 10;
    }
    if (isFirst) {
    isFirst = false;
    if(key == 'c'){
      setter += 1;
      setter = setter % 3;
    }
    if(key == 'w') {
      try {
      PrintWriter pw = createWriter("daten.xml");
      pw.println("<?xml version=\"1.0\" ?>");
      pw.println("<data>");
      pw.println("<bokses>");
      String line;
      for (int i = 0; i < bokses.size(); i++) {
        Boks box = (Boks)bokses.get(i);
        pw.println("<point x=\"" + (box.x/50) + "\" y=\"" + (linie-box.y) + "\" />");
      }
      pw.println("</bokses>");
      pw.println("<trians>");
      for (int i = 0; i < trians.size(); i++) {
        Trian trian = (Trian)trians.get(i);
        pw.println("<point x=\"" + ((trian.x)/50) + "\" y=\"" + (linie-trian.y) + "\" />");
      }
      pw.println("</trians>");
      pw.println("</data>");
      
      pw.close();
      } catch (Exception e) {
        e.printStackTrace();
        exit();
      }
      exit();
    }
    if (key == 'l') {
      if (!clearFlag) {
        clearFlag = true;
      } else {
        bokses.clear();
        trians.clear();
        clearFlag = false; 
      }  
    }
    else clearFlag = false;
   }
  }
  else isFirst = true;
  noCursor();
  translate(translator, 0);
  if(setter == 0){
    rect((mouseX - translator) - ((mouseX - translator) % 25), (mouseY) - ((mouseY) % 25), 50, 50);
  }
  if(setter == 1){
    x = (mouseX - translator) - ((mouseX - translator) % 25);
    y = (mouseY) - ((mouseY) % 25);
    triangle(x, y - 25 + fall, x + 25, y + 25 + fall, x - 25, y + 25 + fall);
  }
  if(setter == 2){
    fill(255,0,0);
    ellipse(mouseX - translator,mouseY,10,10);
  }
  for (int i = trians.size() - 1;i >= 0;i--) {
    Trian Trian = (Trian) trians.get(i);
    //trian.tick();
    if (Trian.x + translator <= width && Trian.x + translator >= 0) {
        if(mouseX >= Trian.x + translator - 25 && mouseX <= Trian.x + translator + 25 && setter == 2 && mouseY >= Trian.y - 25 && mouseY <= Trian.y + 25){
        fill(255,0,0);
        if(mousePressed){
          trians.remove(i);
        }
      }
      else{
        fill(12, 36, 45);
      }
      Trian.render();
    }
  }
  for (int i = bokses.size() - 1;i >= 0;i--) {
    Boks Boks = (Boks) bokses.get(i);
    //trian.tick();
    if (Boks.x + translator <= width && Boks.x + translator >= 0) {
      
      if(mouseX >= Boks.x + translator - 25 && mouseX <= Boks.x + translator + 25 && setter == 2 && mouseY >= Boks.y - 25 && mouseY <= Boks.y + 25){
        fill(255,0,0);
        if(mousePressed){
          bokses.remove(i);
        }
      }
      else{
        fill(8, 16, 16);
      }
      Boks.render();
    }
  } 
  println("Mouse Position: " + ((mouseX - translator) / 50));
  rectMode(CENTER);
  fill(8, 16, 16, 150);
  line(0,linie,0,0);
  line(0 - translator, linie, width - translator, linie);
  if (clearFlag) {
    text("Are you sure you want to clear? (Press l for yes, any other key for no)",-translator,32);
  }
}
public void mousePressed() {
  if (setter == 0) {
      bokses.add(new Boks((mouseX - translator) - ((mouseX - translator) % 25), linie - ((mouseY) - ((mouseY) % 25))));
  } if(setter == 1) {
      trians.add(new Trian((mouseX - translator) - ((mouseX - translator) % 25), linie - ((mouseY) - ((mouseY) % 25))));
  }
}

class Boks {
  float x = 900, y, fall;
  Boks(float xp, float yp) {
    y = linie - yp;
    x = xp;
  }
  public void render() {
    //fill(8, 16, 16);
    stroke(255);
    rectMode(CENTER);
    rect(x, y, 50, 50);
  }
}

class Trian {
  float x = 900 + 25, y = 0, fall = 0;
  Trian(float xp,float yp) {
    y = linie - yp;
    x = xp;
  }
  public void render() {
    stroke(0);
    //fill(12, 36, 45);
    triangle(x, y - 25 + fall, x + 25, y + 25 + fall, x - 25, y + 25 + fall);
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "LevelEdit" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
