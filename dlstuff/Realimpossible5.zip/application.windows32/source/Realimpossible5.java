import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.video.*; 
import processing.opengl.*; 
import ddf.minim.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Realimpossible5 extends PApplet {





float x = 100, y = 100, xgros = 49, ygros = 49, yb = -1, linie = 650, rot = 0, counter, pyp;
int pmillis, t, freim = 0;
float prevx,prevy,prevc,tcounter;
float translatory;
boolean eksited = false, dorotation, eksiter = true, pmousePressed,practice,level2 = true;
//boolean cmov = false;
//MovieMaker mm;
Minim minim;
Minim minim2;
Minim minim3;
AudioPlayer player;
AudioPlayer player2;
AudioPlayer player3;
float tickspeed = 5, grav = 0.34f, jump = 8.8f;
ArrayList trians = new ArrayList(), bokses = new ArrayList();
public void setup() {

  size(900, 700, OPENGL);
  frameRate(130);
  //if (cmov) {
  //  mm = new MovieMaker(this, width, height, "Realimp.mov");
  //}
  minim = new Minim(this);
  minim2 = new Minim(this);
  minim3 = new Minim(this);
  player = minim.loadFile("music.mp3");
  player2 = minim2.loadFile("Practice.mp3");
  player3 = minim3.loadFile("music2.mp3");
  player.loop();
  //player.cue(27000 * 2);
  yb = -3;
}
public void draw() {
  //frameRate(mouseX + 2);
  //scale(0.5,0.5);
  dorotation = true;
  if (y - translatory <= 250) {
    translatory -= yb;
  }
  if (y - translatory >= 450 && translatory < 0) {
    translatory += yb;
  }
  translate(0, translatory);
  //scale(0.5, 0.5);
  eksited = false; 
  /*if(keyPressed){
   if(key == 'd'){
   tickspeed = 20;
   }
   if(key == 'a'){
   tickspeed = -20;
   }
   y = 251;
   }*/   
  counter = (float)((float)((frameCount - (float)freim) / 50.0f) * (float)tickspeed) * 1 + (constrain(tcounter - 30,0,1000000)) + 0;
  noStroke(); 

  /*
  beginShape(QUADS);
   fill(41, 40, 8);
   vertex(0, 0);
   fill(231, 219, 49);
   vertex(0, height);
   fill(231, 219, 49);
   vertex(width, height);
   fill(41, 40, 8);
   vertex(width, 0);
   endShape();*/

  if(counter % 1 == 0.4f){
    counter += 0.1f;
  }
  rectMode(CENTER);

  yb += grav;// * 5.0f / tickspeed;
  y += yb;
  yb = constrain(yb, -1000, 23);
  if(keyPressed && key == 'f'){
    practice = true;
    prevc = counter;
  }
  if(practice){
    player.pause();
    player2.play();
    player3.pause();
    
  }
  if (y + ygros / 2 >= linie) {
    //println("Jumpzeit " + (frameCount - t));
    yb = 0;
    y = linie - ygros / 2;
    rot = 0;
  }
  translate(x, y);

  stroke(0, 0, 0);

  fill(255, 100, 0);


  if (y != linie - ygros / 2) {
    //rotate(-rot);
  }
  translate(-x, -y);
  if(level2){
    level2();
  }
  else{
    level();
  }

  for (int i = trians.size()-1;i >= 0;i--) {  //start
    if (!eksited) {
      Trian Trian = (Trian) trians.get(i);
      Trian.tick();
      if(Trian.x <= width + 50){
        Trian.render();
      }
      if (Trian.x < -25) {
        trians.remove(i);
      }
      if (x + 25 > Trian.x - 25 + abs((Trian.y + 25) - y) / 2 && x - 25 < Trian.x + 25 -  abs((Trian.y + 25) - y) / 2 && y + 25 > Trian.y - 25 && y - 25 < Trian.y + 25) {
        if(eksiter){
        eksit();
        eksited = true;
        }
      }
      if (abs((Trian.x - 25) - x) <= 25 && abs((Trian.y + 25) - y) <= 25) {
        if(eksiter){
        eksit();
        eksited = true;
        }
      }
      if (abs((Trian.x + 25) - x) <= 25 && abs((Trian.y + 25) - y) <= 25) {
        if(eksiter){
        eksit();
        eksited = true;
        }
      }
    }
  }      //end
  
  for (int i = bokses.size()-1;i >= 0;i--) { //start
    if (!eksited) {
      Boks Boks = (Boks) bokses.get(i);
      Boks.tick();
      if(Boks.x <= width + 50){
        Boks.render();
      }
      if (Boks.x < -25) {
        bokses.remove(i);
      }
      if(abs(mouseX - Boks.x) <= 25 && abs(mouseY - Boks.y) <= 25){
        fill(255);
        //println(i);
        Boks.render();
      }
      if (abs(x - Boks.x) < 50) {
        if (yb <= 0) {
          if (abs(y - Boks.y) < 49 || abs(y - Boks.y) < 49) {
            if(eksiter){
            eksit();
            eksited = true;
            }
          }
        }
        if (yb == 0 && abs(y - Boks.y) < 50) {
          if(eksiter){
          eksit();
          eksited = true;
          }
        }
        if (yb == 0 && abs(Boks.y - y) < 50 && abs(x - Boks.x) < 50) {
          if(eksiter){
          eksit();
          eksited = true;
          }
        }
        if (y == Boks.y) {
          if(eksiter){
          eksit();
          eksited = true;
          }
        }
      }
      if (abs(x - Boks.x) < 50) {
        if (Boks.y == y) {
          if(eksiter){
          eksit();
          eksited = true;
          }
        }
        if (y + 25 > Boks.y - 25) {
          if (y < Boks.y || y - Boks.y > 50) {
            if (pyp + 25 <= Boks.y - 25) {
              y = Boks.y - 50;
              yb = 0;
              rot = 0;
              dorotation = false;
              if (keyPressed && key == ' ' || key == CODED && keyCode == UP && keyPressed) {
                yb = -jump;// * 10.0f / tickspeed;
                t = frameCount;
              }
            }
          }
          else {
            if(eksiter){
            eksit();
            eksited = true;
            }
          }
        }
      }

      if (yb == 0 && abs(Boks.y - y) < 50 && abs(x - Boks.x) < 50) {
        if(eksiter){
        eksit();
        eksited = true;
        }
      }
    }
  }
  //end
  stroke(255);

  line(0, linie + 1, width * 2, linie + 1);
  if (keyPressed) {
    if (key == ' ' && y == linie - ygros/2  || key == CODED && keyCode == UP && y == linie - ygros/2) {
      yb = -jump;// * 10.0f / tickspeed;
      t = frameCount - freim;
    }
  }
  fill(255, 100, 0);
  stroke(0);
  pushMatrix();
  translate(x, y);

  if (y != linie - ygros / 2) {
    rot += TWO_PI / 105;
    if (dorotation) {
      rotate(rot);
    }
  }
  rect(0, 0, xgros, ygros);
  popMatrix();

  pmillis = millis();
  pyp = y;
  //if (cmov) {
  //  if (frameCount / 2 == round(frameCount / 2)) {
  //    mm.addFrame();
  //  }
  //  if (mousePressed) {
  //    mm.finish();
  //    exit();
  //  }
  //}
  if (frameCount % 100 == 0);
  //saveFrame();
  pmousePressed = mousePressed;
}
public void eksit() {
  tcounter = prevc;
  player.rewind();
  player3.rewind();
  counter = 0;
  freim = frameCount;
  if(practice){
    ///counter = prevc;
    
  }
  for (int i = trians.size()-1;i >= 0;i--) {
    Trian Trian = (Trian) trians.get(i);
    trians.remove(i);
  }
  for (int i = bokses.size()-1;i >= 0;i--) {
    Boks Boks = (Boks) bokses.get(i);
    bokses.remove(i);
  }
  bokses = new ArrayList();
  trians = new ArrayList();
}
public void mousePressed(){
  println(frameCount - freim);
}
public void keyPressed(){
    if(keyPressed && key == 's' || key == 'S'){
    level2 = !level2;
    player.rewind();
    player2.rewind();
    freim = frameCount;
    bokses = new ArrayList();
    trians = new ArrayList();
  }
}

class Boks {
  float x = 900 + 25, y, fall;
  Boks(float xp,float yp) {
    y = linie - yp;
    if (counter >= 752) {
      fall = (height) - translatory;
    }
    x = xp + 25;
    if(level2)
    x -= 25;
  }
  public void tick() {
    x -= tickspeed;
    if (x < 75 && counter >= 383 && counter <= 752) {
      fall += 5;
    }
    if (counter >= 752 && fall >= 0) {
      fall -= 13;
    }
    fall = constrain(fall, 0, 5000);
  }
  public void render() {
    fill(8, 16, 16);
    stroke(255);
    rectMode(CENTER);
    rect(x, y + fall, 50, 50);
  }
}

class Trian {
  float x = 900 + 25, y = 0, fall;
  Trian(float xp,float yp) {
    y = linie - yp;
    if (counter >= 752) {
      fall = height - translatory;
    }
    x = xp;
  }
  public void tick() {
    x -= tickspeed;
    if (x < 75 && counter >= 383 && counter <= 752) {
      fall += 5;
    }
    if (counter >= 752 && fall >= 0) {
      fall -= 13;
    }
    fall = constrain(fall, 0, 5000);
  }
  public void render() {
    stroke(0);
    fill(12, 36, 45);
    triangle(x, y - 25 + fall, x + 25, y + 25 + fall, x - 25, y + 25 + fall);
  }
}


public void level() {
  if(counter == 1){
    player.rewind();
    player.loop();
    player2.pause();
    player3.pause();
  }
  if (counter == 95 || counter == 100 || counter == 104 || counter == 4 || counter == 20) {
    bokses.add(new Boks(900, 25));
  }
  if (counter == 24) {
    bokses.add(new Boks(900, 125));
  }
  if (counter == 104) {
    bokses.add(new Boks(900, 75));
    bokses.add(new Boks(900, 125));
  }
  if (counter == 3 || counter == 5 || counter == 13 || counter == 14 || counter == 30 || counter == 31 || counter == 32 || counter == 40 || counter == 41) {
    //bokses.add(new Boks(900,25));
    trians.add(new Trian(925,25));
  }
  if (counter == 28 || counter == 29 || counter == 30 || counter == 31 || counter == 32 ||counter == 33 || counter == 34) {
    bokses.add(new Boks(900, 200));
    if (counter == 30 || counter == 31 || counter == 32) {
      trians.add(new Trian(925,250));
    }
  }
  if (round(counter) == counter)
    //bokses.add(new Boks(900,76));
    if (counter == 50 || counter == 51 ||counter == 55 || counter == 69 || counter == 70 ||counter == 71 || counter == 109 || counter == 110 || counter == 111 || counter == 134 | counter == 135 || counter == 136)
      trians.add(new Trian(925,25));
  if (counter == 118 || counter == 124) {
    trians.add(new Trian(925,75));
    bokses.add(new Boks(900, 25));
  }
  if (counter == 133 || counter == 137) {
    bokses.add(new Boks(900, 25));
  }
  if (frameCount - freim == 150 * 10 ||counter == 155 ||counter == 156 ||counter == 157 ||counter == 158) {// || counter == 162.95){// || counter == 162 + 4.95 || counter == 162 + 9.9){
    bokses.add(new Boks(900, 75));
    trians.add(new Trian(925,25));
  }
  if (counter == 155 || counter == 156 || counter == 157 || counter == 158) {
    bokses.add(new Boks(900, 75));
    bokses.add(new Boks(900, 25));
  }
  if (counter == 161 || counter == 162 || counter == 163 || counter == 164) {
    trians.add(new Trian(925,25));
    //bokses.add(new Boks(900,75));
    //bokses.add(new Boks(900,25));
    //bokses.add(new Boks(900,125));
    bokses.add(new Boks(900, 175));
  }
  if (counter == 167 || counter == 168 || counter == 169 || counter == 170) {
    trians.add(new Trian(925,25));
    /*bokses.add(new Boks(900,75));
     bokses.add(new Boks(900,25));
     bokses.add(new Boks(900,125));
     bokses.add(new Boks(900,175));
     bokses.add(new Boks(900,225));*/
    bokses.add(new Boks(900, 275));
  }
  if (counter == 173 || counter == 174 || counter == 175 || counter == 176) {
    trians.add(new Trian(925,25));
    /*bokses.add(new Boks(900,75));
     bokses.add(new Boks(900,25));
     bokses.add(new Boks(900,125));
     bokses.add(new Boks(900,175));
     bokses.add(new Boks(900,225));
     bokses.add(new Boks(900,275));
     bokses.add(new Boks(900,325));*/
    bokses.add(new Boks(900, 375));
  }
  if (counter == 195 ||counter ==  199.95f || counter == 199.95f + 4.95f || counter == 200.95f + 4.95f || counter == 201.95f + 4.95f) {
    bokses.add(new Boks(900, 25));
  }
  if (counter == 199.95f + 9 || counter == 205 + 9) {
    trians.add(new Trian(925,25));
    bokses.add(new Boks(900, 75));
    trians.add(new Trian(925,125));
  }
  if (counter == 222 || counter == 223 || counter == 224 || counter == 270) {
    bokses.add(new Boks(900, 75));
    trians.add(new Trian(925,25));
  }
  if (counter == 228 || counter == 229 || counter == 230 || counter == 231 || counter == 232 || counter == 267) {
    bokses.add(new Boks(900, 175));
    trians.add(new Trian(925,25));
  }
  if (counter == 236 || counter == 237 || counter == 238 || counter == 239 || counter == 235 || counter == 264) {
    bokses.add(new Boks(900, 275));
    trians.add(new Trian(925,25));
  }
  if (counter == 242 || counter == 243 || counter == 244 || counter == 245 || counter == 246 || counter == 261) {
    bokses.add(new Boks(900, 375));
    trians.add(new Trian(925,25));
  }
  if (counter == 249 || counter == 250 || counter == 251 || counter == 252 ||counter == 255 || counter == 256 || counter == 257 || counter == 258) {
    bokses.add(new Boks(900, 475));
    trians.add(new Trian(925,25));
  }
  if (counter == 252 || counter == 253 || counter == 254) {
    trians.add(new Trian(925,525));
    bokses.add(new Boks(900, 475));
    trians.add(new Trian(925,25));
  }
  if (counter == 202 + 9 || counter == 203 + 9 || counter == 204 + 9 || counter == 205 + 9) {
    bokses.add(new Boks(900, 75));
  }
  if (counter % 1 == 0 && counter >= 280 && counter <= 339) {
    trians.add(new Trian(925,25));
  }
  if (counter == 280 || counter == 281 || counter == 282) {
    bokses.add(new Boks(900, 75));
  }
  if (counter == 285 || counter == 286 || counter == 287 || counter == 294 ||counter == 299 || counter == 304 || counter == 309 || counter == 325 || counter == 330) {
    bokses.add(new Boks(900, 175));
  }
  if (counter == 289 || counter == 290 || counter == 312 || counter == 317 || counter == 333 || counter == 339) {
    bokses.add(new Boks(900, 125));
  }
  if (counter == 320.5f || counter == 321.5f || counter == 322.5f || counter == 336) {
    bokses.add(new Boks(900, 225));
  }
  if (counter % 1 == 0 && counter > 383 && counter <= 600) {
    trians.add(new Trian(925,23));
  }


  if (counter == 501 || counter == 502 || counter == 503 || counter == 524.5f) {
    trians.add(new Trian(925,325));
  }
  if (counter == 383 ||counter == 463.5f || counter == 468.5f) {
    bokses.add(new Boks(900, 25));
  }
  if (counter == 387.5f || counter == 439 || counter == 444 || counter == 451 || counter == 456 || counter == 461 || counter == 473) {
    bokses.add(new Boks(900, 75));
  }
  if (counter == 392 || counter == 437 || counter == 448.5f || counter == 477.5f || counter == 484.5f || counter == 551 || counter == 552 || counter == 553 || counter == 554) {
    bokses.add(new Boks(900, 125));
  }
  if (counter == 396.5f || counter == 415.5f || counter == 420.5f || counter == 435 || counter == 482 || counter == 489 || counter == 548.5f || counter == 565 || counter == 566 || counter == 567) {
    bokses.add(new Boks(900, 175));
  }
  if (counter == 401 || counter == 408 || counter == 413 || counter == 425 || counter == 433 || counter == 494 || counter == 546 || counter == 556.5f || counter == 561.5f || counter == 562.5f || counter == 571.5f) {
    bokses.add(new Boks(900, 225));
  }
  if (counter == 405.5f || counter == 429.5f || counter == 430.5f || counter == 431.5f || counter == 499 || counter == 500 || counter == 501 || counter == 502 || counter == 503 || counter == 504) {
    bokses.add(new Boks(900, 275));
  }
  if (counter == 505 || counter == 522 || counter == 524.5f || counter == 527 || counter == 532 || counter == 537 || counter == 543.5f || counter == 576 || counter == 593 || counter == 598) {
    bokses.add(new Boks(900, 275));
  }
  if (counter == 509.5f || counter == 514.5f || counter == 519.5f || counter == 541 || counter == 580.5f || counter == 585.5f || counter == 590.5f) {
    bokses.add(new Boks(900, 325));
  }



  if (counter == 612 || counter == 613 || counter == 614 || counter == 636 || counter == 637 || counter == 638 || counter == 657 || counter == 658 || counter == 659) {
    trians.add(new Trian(925,25));
  }
  if (counter == 649 || counter == 650 || counter == 651 || counter == 652 || counter == 653) {
    bokses.add(new Boks(900, 25));
  }
  if (counter == 620 || counter == 621 || counter == 622 || counter == 626 || counter == 627 || counter == 628 || counter == 633 || counter == 634 || counter == 635 || counter == 643 || counter == 644 || counter == 645) {
    bokses.add(new Boks(900, 25));
  }
  if (counter == 647 || counter == 648 || counter == 654 || counter == 655 || counter == 656) {
    bokses.add(new Boks(900, 25));
    bokses.add(new Boks(900, 75));
    bokses.add(new Boks(900, 125));
  }

  if (counter == 670 || counter == 671 || counter == 672 || counter == 679 || counter == 680 || counter == 681 || counter == 688 || counter == 689) {
    bokses.add(new Boks(900, 25));
    bokses.add(new Boks(900, 75));
  }


  if (counter == 752 || counter == 825 || counter >= 836 && counter <= 839 && counter % 1 == 0) {
    bokses.add(new Boks(900, 25));
  }
  if (counter == 756.5f || counter == 829.5f) {
    bokses.add(new Boks(900, 75));
    trians.add(new Trian(925,25));
  }
  if (counter == 761 || counter == 780 || counter <= 820 && counter >= 780 && counter % 1 == 0 || counter == 833 || counter == 834 || counter == 835 || counter == 840 || counter == 841) {
    bokses.add(new Boks(900, 125));
    trians.add(new Trian(925,25));
  }
  if (counter == 765.5f || counter == 772.5f || counter == 777.5f || counter == 790 || counter == 797) {
    bokses.add(new Boks(900, 175));
    trians.add(new Trian(925,25));
  }
  if (counter == 770 || counter == 790 || counter == 797) {
    bokses.add(new Boks(900, 225));
    trians.add(new Trian(925,25));
    if (counter < 770)
      trians.add(new Trian(925,175));
    trians.add(new Trian(925,25));
  }
  if (counter == 800) {
    trians.add(new Trian(925,25));
    bokses.add(new Boks(900, 325));
    trians.add(new Trian(925,175));
  }
  if (counter == 805.5f) {
    trians.add(new Trian(925,25));
    bokses.add(new Boks(900, 375));
    trians.add(new Trian(925,175));
  }
  if (counter == 803 || counter == 811) {
    trians.add(new Trian(925,25));
    bokses.add(new Boks(900, 425));
    trians.add(new Trian(925,175));
  }
  if (counter == 820) {
    trians.add(new Trian(925,25));
    trians.add(new Trian(925,175));
  }
  if (counter == 836 || counter == 837 || counter == 838 || counter == 839) {
    trians.add(new Trian(925,75));
    trians.add(new Trian(925,25));
  }
  if (counter == 1) {
    bokses.add(new Boks(85 * 50, 25));
  }
  if (counter <= 357) {
    background(190, 190, 30);
  }
  else if (counter <= 399) {
    background(15, 15, 30);
  }
  else if (counter <= 396.8f) {
    background(15, 15, 30);
  }
  else if (counter <= 728.0f) {
    background(100, 0, 0);
  }
  else if (counter <= 752.0f) {
    background(0, 0, 0);
  }
  else {
    background(30, 150, 0);
  }
}
public void level2() {
  player.pause();
  int puller = 0;
  background(30,190,190);
  if (counter == 1) {
    player3.loop();
    XML xml = loadXML("daten.xml");
    //xml = xml.getChild(1);
    
    XML points = xml.getChild(1);
    XML trianer = xml.getChild(3);
    //XMLElement beider = xml.getChild(2);
    for (int i = 0; i < points.getChildCount(); i++) {
      XML punkt = points.getChild(i);
      if ((punkt+"").equals("")) continue;
      bokses.add(new Boks(punkt.getFloat("x") * 50 - puller - 25, punkt.getFloat("y")));
    }
    for (int i = 0; i < trianer.getChildCount(); i++) {
      XML trian = trianer.getChild(i);
      if ((trian+"").equals("")) continue;
      trians.add(new Trian(trian.getFloat("x") * 50 - puller - 25, trian.getFloat("y")));
    }
    /*for (int i = 0; i < beider.getChildCount(); i++) {
      XMLElement beides = beider.getChild(i);
      trians.add(new Trian(beides.getFloat("x") * 50 - puller, 25));
      bokses.add(new Boks(beides.getFloat("x") * 50 - puller - 25, beides.getFloat("y")));
    }*/
  }
  if(frameCount - freim >= 1740){
    translate(width / 2,height / 2);
    rotate(constrain((float)(frameCount - freim - 1740) / 20.0f,0,PI));
    translate(-(width / 2), -(height / 2));
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Realimpossible5" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
